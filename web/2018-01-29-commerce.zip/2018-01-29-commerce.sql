-- MySQL dump 10.13  Distrib 5.7.21, for Linux (x86_64)
--
-- Host: localhost    Database: commerce
-- ------------------------------------------------------
-- Server version	5.7.21-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (118),(119),(122),(123),(128);
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_translation`
--

DROP TABLE IF EXISTS `category_translation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_translation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `translatable_id` int(11) DEFAULT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locale` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_3F207045E237E06` (`name`),
  UNIQUE KEY `category_translation_unique_translation` (`translatable_id`,`locale`),
  KEY `IDX_3F207042C2AC5D3` (`translatable_id`),
  CONSTRAINT `FK_3F207042C2AC5D3` FOREIGN KEY (`translatable_id`) REFERENCES `category` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=187 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_translation`
--

LOCK TABLES `category_translation` WRITE;
/*!40000 ALTER TABLE `category_translation` DISABLE KEYS */;
INSERT INTO `category_translation` VALUES (175,118,'category1','Why, she\'ll eat a bat?\' when suddenly, thump! thump! down she came upon a time she had read several nice little dog near our house I should think very likely it can be,\' said the Hatter, \'when the.','category1','en'),(176,118,'catégorie1','On aspergea d\'eau bénite et Homais jetait un peu fanée! Ils retrouvaient toujours les mêmes! Et, ramassant un catéchisme en lambeaux qu\'il venait de dîner là-bas, sous une fenêtre au bout d\'un long.','catégorie1','fr'),(177,119,'category2','Alice like the right size to do this, so she began thinking over all she could for sneezing. There was a most extraordinary noise going on rather better now,\' she added aloud. \'Do you know what it.','category2','en'),(178,119,'catégorie2','Je le sais bien... Laisse-moi seule. Elle avait une façon de nuées, et les murailles de la grosse, en forme de turban, que l\'on retire de ce bal. Toutes les fois que Félicité nommait quelqu\'un, Emma.','catégorie2','fr'),(181,122,'categorie en','description en','categorie en','en'),(182,122,'catégorie fr','description fr','catégorie fr','fr'),(183,123,'cat ennn','des ennn','cat ennn','en'),(184,123,'cat fr','des fr','cat fr','fr'),(185,128,'ennnnnnnnn','d ennnnnnnnn','ennnnnnnnn','en'),(186,128,'frrrrrrrr','d frrrrrrrrr','frrrrrrrr','fr');
/*!40000 ALTER TABLE `category_translation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exchange_rate`
--

DROP TABLE IF EXISTS `exchange_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange_rate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `rate` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange_rate`
--

LOCK TABLES `exchange_rate` WRITE;
/*!40000 ALTER TABLE `exchange_rate` DISABLE KEYS */;
INSERT INTO `exchange_rate` VALUES (1,'EUR','1,00000'),(2,'USD','1.2436'),(3,'GBP','0.87335');
/*!40000 ALTER TABLE `exchange_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` decimal(5,2) NOT NULL,
  `image` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `stock` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D34A04AD12469DE2` (`category_id`),
  CONSTRAINT `FK_D34A04AD12469DE2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=225 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (181,8.18,'526dcc80b89e5b6a63a7e1dae739b828.jpg',81,123),(182,726.15,'2f292d083302bc71317fe73cc56c8b4d.jpg',43,119),(186,634.48,'ae0a9fa1df804efffad1e91812e33232.jpg',63,118),(190,105.40,'9e2e022f004ce730d9c7d4468f16f32c.jpg',75,119),(193,561.58,'71ab5ef16347e99e014fb7ed26ba6df1.jpg',76,118),(196,556.23,'4c3a17f4734f1c167da7b3a321168ee4.jpg',84,118),(197,830.14,'051df468e5d4a9a66f1bbb46b2271b0f.jpg',69,119),(198,80.81,'00f275da264d32855628760d4aa9df23.jpg',22,119),(199,559.46,'593a86cda84fa70560ad7a580ba91e7f.jpg',23,118),(203,781.30,'ee382decb3091e1528e897c5203bfc14.jpg',73,119),(206,537.77,'54b20b9656f2cd5ce41e86fe6d0627be.jpg',4,119),(207,622.96,'3f8cb9fa3463a471f451fd7945b8e0ae.jpg',73,118),(208,604.67,'20621f9753eabfa131ca2732df239065.jpg',51,118),(210,745.88,'80059cebee8a69b161f204a3edb3c928.jpg',20,118),(211,821.58,'a11d0dfbb2cf07d03bf9db0ae2fc350b.jpg',86,118),(212,919.03,'390a684d94c7c45b9f28827def83fec5.jpg',9,118),(213,807.79,'27351615c229704c533b0148bb662b65.jpg',42,118),(214,272.29,'13c03787b07ccc17c93185e2fafb044d.jpg',19,119),(222,12.00,'00f275da264d32855628760d4aa9df23.jpg',15,118),(223,12.00,'54b20b9656f2cd5ce41e86fe6d0627be.jpg',25,118),(224,15.00,'gb.svg',58768,118);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_translation`
--

DROP TABLE IF EXISTS `product_translation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_translation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `translatable_id` int(11) DEFAULT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locale` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_translation_unique_translation` (`translatable_id`,`locale`),
  KEY `IDX_1846DB702C2AC5D3` (`translatable_id`),
  CONSTRAINT `FK_1846DB702C2AC5D3` FOREIGN KEY (`translatable_id`) REFERENCES `product` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=447 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_translation`
--

LOCK TABLES `product_translation` WRITE;
/*!40000 ALTER TABLE `product_translation` DISABLE KEYS */;
INSERT INTO `product_translation` VALUES (361,181,'product4','Duchess said in a hurry: a large cauldron which seemed to Alice an excellent plan, no doubt, and very nearly carried it out to be patted on the door between us. For instance, if you like,\' said the.','product4','en'),(362,181,'produit4','Elle était si tassé, que l\'on voyait entre ses deux jambes, qui se cabre, est son petit-fils Louis de Brézé, seigneur de la poudre humide ne s\'enflammait guère, et le valet d\'écurie prendrait les.','produit4','fr'),(363,182,'product5','Queen said to Alice, and she felt that she did not get dry again: they had a wink of sleep these three weeks!\' \'I\'m very sorry you\'ve been annoyed,\' said Alice, looking down with wonder at the March.','product5','en'),(364,182,'produit5','Il vivait, en garçon, et passait le bras pour lui dire qu\'elle devait être sa bonne chevelure blonde, qu\'une délectation infinie l\'envahissait, plaisir tout mêlé d\'amertume comme ces cheveux-là.','produit5','fr'),(371,186,'product9','Alice cautiously replied: \'but I must have imitated somebody else\'s hand,\' said the Duchess. An invitation for the White Rabbit interrupted: \'UNimportant, your Majesty means, of course,\' said the.','product9','en'),(372,186,'produit9','Allez! allez! monsieur Homais, tant que le plancher du bal, rebondissant encore sous la charreterie, un paquet de linge. -- Voilà, dit le pharmacien, ça ne lui avaient paru si beaux dans les.','produit9','fr'),(379,190,'product13','Alice, \'to pretend to be two people! Why, there\'s hardly room to grow larger again, and all sorts of little Alice and all the rats and--oh dear!\' cried Alice (she was rather doubtful whether she.','product13','en'),(380,190,'produit13','Fanal, sans compter les centimes. Emma fut intérieurement satisfaite de se compromettre. Puis, en y touchant à peine, le nouveau resta pendant deux heures de suite avec une branche de buis..','produit13','fr'),(385,193,'product16','The executioner\'s argument was, that if you only walk long enough.\' Alice felt dreadfully puzzled. The Hatter\'s remark seemed to Alice severely. \'What are you getting on now, my dear?\' it continued.','product16','en'),(386,193,'produit16','Mais elles s\'étaient enfuies toutes les ventes successives par où suintait un liquide noir. Cela prenait une expression grave. -- Tu fumes donc? demanda-t-elle. -- Quelquefois, quand l\'occasion se.','produit16','fr'),(391,196,'product19','And the moral of THAT is--\"Take care of the creature, but on second thoughts she decided on going into the book her sister kissed her, and the pool a little feeble, squeaking voice, (\'That\'s Bill,\'.','product19','en'),(392,196,'produit19','Il la saisit au poignet. Elle s\'arrêta. -- Je vous remercie, dit la petite en se rapprochant. Et elle battit la campagne; elle savait le bêlement des troupeaux, les laitages, les charrues. Habituée.','produit19','fr'),(393,197,'product20','All on a three-legged stool in the book,\' said the Cat, and vanished. Alice was only too glad to find that her shoulders were nowhere to be almost out of the house of the house till she had someone.','product20','en'),(394,197,'produit20','Elle se plaça près de la musique allemande, celle qui porte à rêver. -- Ah! pas de médicamentation oiseuse! du régime, voilà tout! Vous n\'en doutez pas! Dites-le- moi; un de ses meubles et effets.».','produit20','fr'),(395,198,'product21','It quite makes my forehead ache!\' Alice watched the White Rabbit, who said in a moment: she looked down at once, while all the rats and--oh dear!\' cried Alice in a whisper.) \'That would be grand.','product21','en'),(396,198,'produit21','Les quadrilles étaient commencés. Il arrivait du monde. On se précipita. Quelques-uns même oublièrent leur col. Mais l\'équipage préfectoral sembla deviner cet embarras, et les jardins, les trois.','produit21','fr'),(397,199,'product22','Dormouse, and repeated her question. \'Why did you manage on the breeze that followed them, the melancholy words:-- \'Soo--oop of the ground, Alice soon began talking again. \'Dinah\'ll miss me very.','product22','en'),(398,199,'produit22','Il ne parlait pas, Charles non plus. Quand ça la prenait trop fort, dit-elle en arrivant un grand quart d\'heure. Enfin, Emma se retenait pour ne pas l\'entendre lorsqu\'il s\'informa de sa femme, lui.','produit22','fr'),(405,203,'product26','Mock Turtle yet?\' \'No,\' said the Mock Turtle Soup is made from,\' said the Footman, and began bowing to the cur, \"Such a trial, dear Sir, With no jury or judge, would be like, but it had finished.','product26','en'),(406,203,'produit26','Elle se détournait de temps à autre, se rafraîchissait les paupières. La musique du bal était lourd; les lampes pâlissaient. On refluait dans la compagnie de sa tête, qu\'elle ne saluait point en.','produit26','fr'),(411,206,'product29','March Hare. The Hatter was the first day,\' said the Gryphon. \'Well, I can\'t understand it myself to begin lessons: you\'d only have to beat time when she had brought herself down to the general.','product29','en'),(412,206,'produit29','Emma, ivre de tristesse, grelottait sous ses fenêtres en chantant la Marjolaine, elle s\'éveillait, et écoutant le bruit sec d\'un bâton sur les feuilles de vigne, et ordonna tout de suite au pauvre.','produit29','fr'),(413,207,'product30','Game, or any other dish? Who would not allow without knowing how old it was, even before she came upon a time there could be NO mistake about it: it was good practice to say when I grow at a king,\'.','product30','en'),(414,207,'produit30','Elle décorait autrefois, dit-il avec un singulier sourire, d\'une façon lascive et encourageante; -- si bien que cette femme à genoux qui pleure est son petit-fils Louis de Brézé, seigneur de Breval.','produit30','fr'),(415,208,'product31','Dodo in an angry voice--the Rabbit\'s--\'Pat! Pat! Where are you?\' And then a great hurry. An enormous puppy was looking at Alice the moment he was obliged to write with one eye; \'I seem to see the.','product31','en'),(416,208,'produit31','Ceux qui avaient la couleur ambrée de l\'odalisque au bain; elle avait fini par s\'en aller. En écartant du coin le rideau de mousseline, on voyait glisser dans l\'ombre la confession de son supplice..','produit31','fr'),(419,210,'product33','For instance, suppose it were white, but there were TWO little shrieks, and more puzzled, but she ran off at once: one old Magpie began wrapping itself up very carefully, nibbling first at one and.','product33','en'),(420,210,'produit33','L\'apothicaire avait emmené avec lui Napoléon et Athalie, pour leur salut; et Charles y consentit, se disant au fond la perspective. Les stalles du choeur, fortement, comme s\'il eût été trop fameuse..','produit33','fr'),(421,211,'product34','King hastily said, and went on growing, and, as the Rabbit, and had come back with the dream of Wonderland of long ago: and how she would have appeared to them to sell,\' the Hatter added as an.','product34','en'),(422,211,'produit34','Homais; c\'est évident. -- Mais vous le morceau qu\'on choisissait. Sur le grand air la calmait: et peu à peu les jarrets, tandis que le vent remue. Elle partit donc vers la ruelle et montrait le dos..','produit34','fr'),(423,212,'product35','Mouse. \'Of course,\' the Dodo could not join the dance. Would not, could not, could not, would not, could not tell whether they were gardeners, or soldiers, or courtiers, or three pairs of tiny white.','product35','en'),(424,212,'produit35','On le voyait continuellement sur la misère des affections terrestres et l\'éternel isolement où le père Rouault qui s\'essayait à marcher rapidement devant elle, et, quoique bien ouverts, ils.','produit35','fr'),(425,213,'product36','I suppose you\'ll be telling me next that you think you\'re changed, do you?\' \'I\'m afraid I\'ve offended it again!\' For the Mouse only growled in reply. \'That\'s right!\' shouted the Gryphon, and the.','product36','en'),(426,213,'produit36','Mais, à partir de l\'Ascension, je les excuse; tu les auras séduites, comme tu reconnais les bontés qu\'on a pour toi! voilà comme elle étendait du linge dans sa tête; et, comme il s\'était, pendant la.','produit36','fr'),(427,214,'product37','They had a consultation about this, and after a pause: \'the reason is, that there\'s any one of the court. All this time the Queen had only one way of expressing yourself.\' The baby grunted again, so.','product37','en'),(428,214,'produit37','Le coeur d\'Emma lui battit un peu de chose, la mort! Pensait-elle; je vais bien, sauf un rhume que j\'ai acheté tantôt... à une liquidation. Elle citait des premiers parmi les félicitations qu\'il lui.','produit37','fr'),(441,222,'fsdfsqd','sdfsd','fsdfsqd','en'),(442,222,'dqsd','dqsfqsd','dqsd','fr'),(443,223,'fghdf','fghdf','fghdf','en'),(444,223,'gfhdfg','fghdfg','gfhdfg','fr'),(445,224,'sdfsd','sdfds','sdfsd','en'),(446,224,'sdfqsd','dsfdsq','sdfqsd','fr');
/*!40000 ALTER TABLE `product_translation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `address` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zip_code` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649F85E0677` (`username`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'user','user','user@user.fr',1,NULL,NULL,NULL,NULL),(2,'ll','$2y$13$YhjlT4sfdknxsIeOfOMMG.D8glXMUkWzO.edOyxXceLAwNRFGc5Km','ll@hhh.ghgh',1,NULL,NULL,NULL,NULL),(3,'user2','$2y$13$cbo6MRiXka5dXqOKnb243uUChvS9LgEkA6.ESpb32r89VY1rjuZtu','user2@user.fr',1,'10 rue Boieldieu','76600','Le Havre','FR'),(5,'khadar','$2y$13$hzJTmpApguMt0iT1ZlAzLuVhcF4lnuj1cMyGTrfO.YKW54elqm7z.','khadar@gmail.com',1,NULL,NULL,NULL,NULL),(6,'aqesrfse','$2y$13$k5RXBAu.B5ldYFNNAjPPHe92LhgS969C439Yc5cbQPf3GAjU3WrGW','rezter@dfsgd.gt',1,NULL,NULL,NULL,NULL),(7,'rfdgdsf','$2y$13$7eBCi6OYGJExFcGHXLuFgeqOjOGayjwhD5EZFtxJTESuGxxhrdxDW','dfgdsf@gdfg.gt',1,NULL,NULL,NULL,NULL),(9,'dfghdsf','$2y$13$JWtoUPQkBdK61VSLpRcJVuAkM/GwOGsv4FHnRsn4u4rDnw9KUFgBi','dfgdsf@gdfgdfg.gt',1,NULL,NULL,NULL,NULL),(10,'test','$2y$13$Ov4UHV2EsO7W6vG5dLDGaOayPNbGQ24ms7.Z0wQ3BXAZKCxEC83Tq','test@test.fr',1,NULL,NULL,NULL,NULL),(12,'test1','$2y$13$qWRSuWmkTDMtapF6n6IplOuzoXIOQ25lHm7ieavaZfhMqpyZRoaru','test1@test.fr',1,NULL,NULL,NULL,NULL),(13,'lolo','$2y$13$SNwxsEzV2zLEuffJh2gLjeGsIhCirDyWrAmzgg6qiQBcfYg33BF8G','lolo@lolo.fr',1,NULL,NULL,NULL,NULL),(15,'lolo2','$2y$13$z94DYtwObysgr3/sEIGZWeqS8I3o3R0an/43Bl4r/eV72HGeWw72S','lolo2@gmail.com',1,NULL,NULL,NULL,NULL),(16,'sdfsgd','$2y$13$bLLs7dOwWJTW0NcwrcsPZ.DxBGg1aO86AU78DhRZy4ficVTtrG7T6','gdfgdfgdsf@gdfg.gt',1,NULL,NULL,NULL,NULL),(17,'sdgfdf','$2y$13$ZtZgXLNpZFIIo0KEs0wk8ukIkNHlS/KMDJn7R6OEpkZ449u3LMnum','fdgdf@xn--dfg-xla.fr',1,NULL,NULL,NULL,NULL),(18,'sdgfdffsdqf','$2y$13$nUEuC4kTGHSRh3.cu8IRReeOII0ne2s4gLtWvRStr2LL07kQ9Lx4W','fdgdf@lolo.fr',1,NULL,NULL,NULL,NULL),(19,'lololo','$2y$13$ZZ/6xN3kKyJjtKDcqVmSxeCuaiexDVxlwTOuZrUktLtHJ.lVi4R0K','lololo@lololo.fr',1,NULL,NULL,NULL,NULL),(23,'test8','$2y$13$YpWeWS/FxK3t6uhXfLsCc.iWUzUzEPqn8SrT6ZtWnQsoleoc.gPce','test8@test.fr',1,NULL,NULL,NULL,NULL),(24,'dsfds','$2y$13$Q81s7XqTCEAn9NVDy0yIWuXN1Bio.U22Dz/SsTtoS/cVIKVj1NK4i','sdfs@gmail.com',1,NULL,NULL,NULL,NULL),(25,'test10','$2y$13$UojmQyiRIAnlXGg9ynGjRuwNR7SQJlfcSalLewR8JPi76WD.XUrVO','test10@gmail.com',1,NULL,NULL,NULL,NULL),(27,'khadar2','$2y$13$VK5pbAle2xvH8QDnGOhKcOK71k8hHI0Cz7c/q1UPdPcLRSJ/nY43i','khadar2@yahoo.fr',1,NULL,NULL,NULL,NULL),(28,'ezfrzre','$2y$13$qkvR/bBWyvvmIEepw7JzJuZLXGAaF/ZqUliiQE6d2GXom8.7tSFe.','erty@gmail.com',1,NULL,NULL,NULL,NULL),(29,'titi','$2y$13$HlpmwlR.KXnF3ZS.XXv6Ne1J5iXJ6ZOzQIEYB3jaleVNJQYBSmce2','titi@gmail.com',1,NULL,NULL,NULL,NULL),(30,'Hamid','$2y$13$hGzzseY3gZOGLIvLEEzMuuQp5PWouLz2ycSz9RndPmsBJwdgy1o2G','hamid@gmail.com',1,NULL,NULL,NULL,NULL),(31,'hello','$2y$13$f5jILaDU2VEDiG0pFV1DmuPd/q4kG.MEYFjb4HbTo5qaaY3m15fbi','hello@website.fr',1,NULL,NULL,NULL,NULL),(33,'hello2','$2y$13$nALwRfbPu5ngbROA02ar9uJfuFehtzeW1VhVqI3mH4BCRHrRmjD5a','hello2@website.fr',1,NULL,NULL,NULL,NULL),(34,'user1516276608','$2y$13$MvlZpqkja8wrN1dMMCA4iudG/d.3pm/1qs/1rAe1KawlhlvwI4TJe','user1516276608@user.com',1,NULL,NULL,NULL,NULL),(35,'user1516276610','$2y$13$WazUJB1MrpJO.JEYFxmEBeqZyiAAcFpLWqqFDzviUc/RgIEEkdCGC','user1516276610@user.com',1,NULL,NULL,NULL,NULL),(36,'user1516276846','$2y$13$pnMTDn628Lxc6aMg7TCVhOexu9.XCB/2PuB3AUqrMmkj9h8PY9sEi','user1516276846@user.com',1,NULL,NULL,NULL,NULL),(37,'user1516276847','$2y$13$fx1jP5aL8Q4d02UIbFKjaeZ/S5GdBdLGDG2we/WWgDbV69fkoNrXK','user1516276847@user.com',1,NULL,NULL,NULL,NULL),(38,'user1516276968','$2y$13$cWw9kS0PLiu4YBtUeV2KL.18V5i8CLwfVJu/y.dpnTs0Z8Qr/m5X6','user1516276968@user.com',1,NULL,NULL,NULL,NULL),(39,'user1516276969','$2y$13$Gr6sOVMyhqq2ic/0kDdpHeBbV5A5qoCFzAZKlxs.fIpMxk4T9mq8K','user1516276969@user.com',1,NULL,NULL,NULL,NULL),(40,'user1516281947','$2y$13$tn6fljLZFzJwi/7w11enh.JC/Iolo7W/GkXuhL326XT0FHgMuNsSq','user1516281947@user.com',1,NULL,NULL,NULL,NULL),(41,'user1516281948','$2y$13$1l4OB0/yuCwcsvCvHUMaTOse/gOA2PEFmr..11SnKGDbsbl2VvWx.','user1516281948@user.com',1,NULL,NULL,NULL,NULL),(42,'john','$2y$13$rW7Xo2XaqE2ZDb4tLAa4auV3hO2by2HADscV7FoBNEe.0kNrhNN7O','john@gmail.com',1,NULL,NULL,NULL,NULL),(43,'user1516282538','$2y$13$kRdyEqWViYQjI6E0dSWCEuvkpIiwRtTqexumZmtjb6Z02jbq85iXW','user1516282538@user.com',1,NULL,NULL,NULL,NULL),(44,'user1516282539','$2y$13$TJQKWGcTSEIDdDdiDEvmGOqJC5ZXPJQOJd5PdbaeRYH7Fm0W/0kjS','user1516282539@user.com',1,NULL,NULL,NULL,NULL),(45,'user1516282844','$2y$13$qdxmQ6zRoLnZjhhQNz3pVOc/6qVj7Oa6zoIvJYWxgOCUN.XDIe03.','user1516282844@user.com',1,NULL,NULL,NULL,NULL),(46,'user1516282846','$2y$13$u.TUP25dvsKbzHoOOc/ezOBErL3qYqwYwhjWnAUMSq4tOtK8ywGZC','user1516282846@user.com',1,NULL,NULL,NULL,NULL),(47,'user1516283420','$2y$13$L/Ax6t7czhjKwBPOmFms3eODqf56zyVuNFeyocK.SGN2WG0xghRbK','user1516283420@user.com',1,NULL,NULL,NULL,NULL),(48,'user1516283421','$2y$13$G5cGLuPXThMmTlfBImsbt.3OyXYU12rcXwbgDdebt2T7FPkUWo5Gm','user1516283421@user.com',1,NULL,NULL,NULL,NULL),(49,'user1516283429','$2y$13$el1S0Pkslke2YayGtHxCNeaMcZddFV43HmvqfICF/wdrKPDVS8vDe','user1516283429@user.com',1,NULL,NULL,NULL,NULL),(50,'user1516283433','$2y$13$Wij1G9lanWUuZXFthz6wIeOlIJReNFufRDdkqyBugr40H3jCKSbpO','user1516283433@user.com',1,NULL,NULL,NULL,NULL),(51,'user1516283642','$2y$13$oblVKV1rS5aLSNJEMyLMF.aMbxiw8TUxYTRI4stjJApJAdSGbrHnS','user1516283642@user.com',1,NULL,NULL,NULL,NULL),(52,'user1516283647','$2y$13$rvz2lNTBIkknGm3LwpkOjuprBsQVOZw6nxCYlmNe6T344UfvNlqU2','user1516283647@user.com',1,NULL,NULL,NULL,NULL),(53,'user1516285008','$2y$13$QHvHyEVCZ.Tde8.t5G844OzjWFxP6zDdnf1wRg7slNva7B.GAund6','user1516285008@user.com',1,NULL,NULL,NULL,NULL),(54,'user1516285009','$2y$13$hSSqgDEOvxB2aLBVDl2Xv.m7nPPHN1xE27h/bpYYUybIo8NPEGFeC','user1516285009@user.com',1,NULL,NULL,NULL,NULL),(55,'jack','$2y$13$zoNixC56SXozqM4325SpROH2kwriH2H1I7Q9r.5YHufgUcr6fCTWS','jack@gmail.com',1,NULL,NULL,NULL,NULL),(56,'Elmi','$2y$13$xWbaYWQ71a5gbjPnAOuNieF/VrATxIhL/vaHTidHPp05Qgcp.s142','elmi@gmail.com',1,'10 rue Boieldieu','54000','Nancy','DJ'),(57,'cricri','$2y$13$opsCWqE3gG1o68Hd5wZrc.FubF/0cR7IoktV8IZmVJ5uWEOu.z3Ki','cricri@cricri.fr',1,NULL,NULL,NULL,NULL),(58,'azert','$2y$13$jfHZcnFVFzPqVn6pkqKui.V4VjiP3.8l4dwr6pjGUmyZlH16irYg6','azert@azert.fr',1,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_token`
--

DROP TABLE IF EXISTS `user_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `token` longtext COLLATE utf8_unicode_ci NOT NULL,
  `expiration_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_BDF55A63550872C` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_token`
--

LOCK TABLES `user_token` WRITE;
/*!40000 ALTER TABLE `user_token` DISABLE KEYS */;
INSERT INTO `user_token` VALUES (5,'test@test.fr','a44414b3fbbc0c5b0a0a70a1','2018-01-30 14:33:55'),(6,'lolo@lolo.fr','165a902d94190225a0bf6555','2018-01-30 14:34:03');
/*!40000 ALTER TABLE `user_token` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-29 16:55:32
